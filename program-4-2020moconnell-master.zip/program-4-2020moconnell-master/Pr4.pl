exactly3(X):- X = [A,B,C].

at_least_3(X):- X = [A,B,C|T].

at_most_3(X):- X = [].
at_most_3(X):- X = [A].
at_most_3(X):- X = [A,B].
at_most_3(X):- X = [A,B,C].

intersect(X,Y):- member(A,X), member(A,Y). all_intersect([],_).

all_intersect([H|T],Y):- intersect(H,Y), all_intersect(T,Y).
