module Chs67 where

--don't delete the import, obviously
--remember to include function types (3 points each)

sumdown 0 = 0
sumdown n = n + sumdown(n-1)

euclid :: (Integral a) => a -> a -> a
euclid x y = euclid_ (abs x) (abs y)
  where
    euclid_ a 0 = a
    euclid_ a b = euclid_ b (a `rem` b)

sum' :: Num a => [a] -> a
sum' [] = 0
sum' (x:xs) = x + sum xs

take' :: Int -> [a] -> [a]
take' 0 _ = []
--take' n [] = []
take' n (x:xs) = x : take' (n-1) xs 

last' :: [a] -> a
last' (x:[]) = x
last' (x:xs) = last xs

dec2int' :: [Int] -> Int
dec2int' = foldl (\x y -> 10*x + y) 0

altmap :: (a -> b) -> (a -> b) -> [a] -> [b]
altmap f g [] = []
altmap f g (x:[]) = f x : []
altmap f g (x:y:xs) = f x : g y : altmap f g xs

--define your own function(s) to help with luhn

double :: Int -> Int
double x = if n < 10 then n else n - 9
  where n = x*2
mod10 :: Integral a => a -> Bool
mod10 x = (mod x 10) == 0

luhn :: [Int] -> Bool
luhn = mod10 . sum . (altmap double id)
