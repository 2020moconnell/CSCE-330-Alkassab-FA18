{- our "menu"
 head, tail, !!, take, drop, length, sum, product, ++, reverse
-}

--Q3


--Q4


--Q4 yet another way


--Q4 alt (with recursion)


--Q5 - init


--q5 - alt


--q5 - recursion
