
--https://wiki.haskell.org/Haskell_in_5_steps
--ghc -o hello helloWorld.hs

main = putStrLn "Hello World!"