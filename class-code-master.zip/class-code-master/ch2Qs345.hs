{-
 head, tail, !!, take, drop, length, sum, product, ++, reverse
-}