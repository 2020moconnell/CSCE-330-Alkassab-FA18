-- higher order functions examples... will do many
-- technically, a higher order function is a function that 
-- takes OR returns a function
-- but most functions that take 2+ args return functions 
-- as intermediate values (currying) so we 
-- reserve "higher order" in Haskell for functions
-- that take functions as arguments

-- working recursively




-- using a Higher order function



--or even just
--sum''' :: Num a => [a] -> a


