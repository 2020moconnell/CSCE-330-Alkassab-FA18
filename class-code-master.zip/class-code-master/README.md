# class-code
This is basically a dump of in class examples. You should be able to see both sections. Sometimes we do things different ways in different sections, so comparing Section 1 code to Section 2 code is worthwhile.
