%Maggie OConnell
%Q1
mother(M,C) :- parent(M,C), female(M).

grand_parent(GP,GC) :- parent(GP,Y), parent(Y,GC).

great_grand_mother(GGM,GGC) :- grand_parent(Y,GGC), mother(GGM,Y).

%Q2
sibling(A,B):-parent(Z,A), parent(Z,B), A\=B.
brother(B,Sib):-sibling(B,Sib), male(B).
sister(S,Sib):-sibling(S,Sib), female(S).

%Q3 --
%You have to know both parents for both siblings for half_sibling
half_sibling(S1,S2):- sibling(S1,S2), parent(P,S1), parent(P,S2), parent(A,S1), parent(B,S2), S1\=S2, P\=A, P\=B, A\=B.

full_sibling(S1,S2):- sibling(S1,S2), father(F,S1), father(F,S2), mother(M,S1), mother(M,S2), S1\=S2.

%Q4
first_cousin(C1,C2):-parent(P1,C1), parent(P2,C2), sibling(P1,P2), C1\=C2.

second_cousin(C1,C2):-parent(P1,C1), parent(P2,C2), first_cousin(P1,P2), C1\=C2.

%Q5
half_first_cousin(C1,C2):-parent(P1, C1), parent(P2,C2), half_sibling(P1,P2), C1\=C2.

double_first_cousin(C1,C2):-parent(P1,C1), parent(P2,C1), parent(P3,C2), parent(P4,C2), sibling(P1,P3), sibling(P2,P4), C1\=C2, P1\=P2, P1\=P3, P1\=P4, P2\=P3, P2\=P4, P3\=P4.

%Q6
first_cousin_once_removed(C1,C2) :- first_cousin(P1,C2), parent(P1,C1), C1\=C2.
%first_cousin_twice_removed(C1,C2):- first_cousin(C2,P2), grand_parent(P2,C1), C1\=C2.
first_cousin_twice_removed(C1,C2) :- first_cousin_once_removed(P1,C2), parent(P1,C1), C1\=C2.
first_cousin_twice_removed(C1,C2) :- grand_parent(GP,C2), first_cousin(C1,GP), C1\=C2.

%Q7
descendant(D,A) :- child(D,A).
descendant(D,A):-child(D,Z), descendant(Z,A).
ancestor(A,D) :- parent(A,D).
ancestor(A,D):-parent(A,Z), ancestor(Z,D).

%Q8
%this version of "cousin" does not handle "____ removed",
%read description carefully
cousin(X,Y):-parent(P1,X), parent(P2,Y), (sibling(P1,P2); cousin(P1,P2)).

%Q9
%do not return anything for closest_common_ancestor(X,X,A).
common_ancestor(A,B,C):- ancestor(C,A), ancestor(C,B), \+ A=B.
closest_common_ancestor(R1,R2,A):- common_ancestor(R1,R2,A), \+ (child(C,A), common_ancestor(R1,R2,C)).

%closest_common_ancestor(R1,R2,A):- ancestor(A,R1), ancestor(A,R2), child(C,A), \+ancestor(C,R1), \+ancestor(C,R2), R1\=R2.
% Q10 -- not scored, but will do
%   write_descendant_chain(jim,anna) and
%   write_descendant_chain(louise,gina) and
%   write_descendant_chain(emma,lily) <-this one shold print nothing
%   (make sure this DOES NOT FAIL (read the instructions carefully)).

write_child(X,Y):-
	write(X), write(' is a child of '), write(Y), nl.

write_descendant_chain(X,Y):- child(X,Y), write_child(X,Y).
write_descendant_chain(X,Y):- child(X,Y), write_child(X,Z), Y\=Z, write_descendant_chain(Z,Y).






